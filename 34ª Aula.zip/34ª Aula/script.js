// LOGIN
document.getElementById('loginForm').addEventListener('submit', function (event) {
    event.preventDefault();

    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (username === 'usuario' && password === 'senha') {
        document.getElementById('message').textContent = 'Login bem-sucedido!';
        window.location.href = 'https://www.youtube.com/';
    } else {
        document.getElementById('message').textContent = 'Credenciais inválidas. Tente novamente.';
    }
});